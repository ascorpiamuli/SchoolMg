<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash; // ✅ Correct

class AuthController extends Controller
{
    public function login(Request $request)
    {
        \Log::info('Login attempt', ['email' => $request->input('email')]);
        $credentials = $request->only('email', 'password');

        if (!Auth::attempt($credentials)) {
            \Log::warning('Login failed', ['email' => $request->input('email')]);
            return response()->json(['message' => 'Invalid credentials'], 401);
        }

        \Log::info('Login successful', ['user_id' => Auth::id()]);
        return response()->json(Auth::user());
    }
    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'full_name'     => 'required|string|max:255',
            'email'         => 'required|string|email|max:255|unique:users',
            'password'      => 'required|string|min:6',
            'role'          => 'required|in:admin,teacher,accountant,parent',
            'phone'         => 'nullable|string|max:9',
            'gender'        => 'nullable|in:male,female,other',
            'address'       => 'nullable|string|max:255',
            'national_id'   => 'nullable|string|max:20',
            'qualification' => 'nullable|string|max:100',
            'subject'       => 'nullable|array',
            'subject.*'     => 'string|max:100',
            'staff_id'      => 'nullable|string|max:50',
            'department'    => 'nullable|string|max:100',
            'child_name'    => 'nullable|string|max:255',
            'child_class'   => 'nullable|string|max:100',
            'child_health'  => 'nullable|string|max:100',
        ]);

        // Prepend +254 to phone if provided and not already present
        $phone = $validatedData['phone'] ?? null;
        if ($phone && strpos($phone, '+254') !== 0) {
            // Remove leading 0 if present
            $phone = ltrim($phone, '0');
            $phone = '+254' . $phone;
        }

        $user = User::create([
            'full_name'     => $validatedData['full_name'],
            'email'         => $validatedData['email'],
            'password'      => Hash::make($validatedData['password']),
            'role'          => $validatedData['role'],
            'phone'         => $phone,
            'gender'        => $validatedData['gender'] ?? null,
            'address'       => $validatedData['address'] ?? null,
            'national_id'   => $validatedData['national_id'] ?? null,
            'qualification' => $validatedData['qualification'] ?? null,
            'subject'       => $validatedData['subject'] ?? [],
            'staff_id'      => $validatedData['staff_id'] ?? null,
            'department'    => $validatedData['department'] ?? null,
            'child_name'    => $validatedData['child_name'] ?? null,
            'child_class'   => $validatedData['child_class'] ?? null,
            'child_health'  => $validatedData['child_health'] ?? null,
        ]);

        return response()->json([
            'message' => 'User registered successfully',
            'user' => $user,
        ], 201);
    }

    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'Logged out']);
    }
}
